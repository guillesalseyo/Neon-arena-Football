const $=id=>document.getElementById(id), canvas=$("canvas"),ctx=canvas.getContext("2d");
let W=1200,H=650, running=false, isHost=false, peer, conn, room="", me="Jugador", other="Rival";
let keys={}, touch={}, last=0, timeLeft=120, goalFlash=0, score=[0,0];
const field={x:80,y:70,w:1040,h:510}, goalH=190, playerR=22;
let p1={x:220,y:325,vx:0,vy:0},p2={x:980,y:325,vx:0,vy:0},ball={x:600,y:325,vx:0,vy:0};

function resize(){canvas.width=innerWidth*devicePixelRatio;canvas.height=innerHeight*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);W=innerWidth;H=innerHeight}
addEventListener("resize",resize);resize();

function setStatus(s){$("status").textContent=s}
function showGame(){ $("menu").classList.add("hidden");$("result").classList.add("hidden");$("game").classList.remove("hidden");running=true;last=performance.now();requestAnimationFrame(loop)}
function resetPositions(){p1={x:field.x+140,y:H/2,vx:0,vy:0};p2={x:field.x+field.w-140,y:H/2,vx:0,vy:0};ball={x:W/2,y:H/2,vx:0,vy:0};timeLeft=120;score=[0,0];updateScore()}
function updateScore(){$("blueScore").textContent=score[0];$("redScore").textContent=score[1]}
function makeRoom(){room=Math.random().toString(36).slice(2,8).toUpperCase();return room}
function startHost(){
 me=$("name").value.trim()||"Jugador"; isHost=true; room=makeRoom(); 
 peer=new Peer("neon-football-"+room,{debug:0});
 peer.on("open",()=>{setStatus("Sala "+room+" creada. Comparte el código.");$("roomInput").value=room;showGame();resetPositions();$("roomLabel").textContent="SALA "+room;$("p1tag").textContent=me});
 peer.on("connection",c=>{conn=c;bindConn();});
 peer.on("error",e=>setStatus("Error de conexión: "+e.type));
}
function startJoin(){
 me=$("name").value.trim()||"Jugador";room=$("roomInput").value.trim().toUpperCase();
 if(!room)return setStatus("Escribe un código de sala.");
 isHost=false;peer=new Peer({debug:0});
 peer.on("open",()=>{conn=peer.connect("neon-football-"+room,{reliable:true});bindConn()});
 peer.on("error",e=>setStatus("No se pudo unir: "+e.type));
}
function bindConn(){
 if(!conn)return;
 conn.on("open",()=>{conn.send({type:"hello",name:me});showGame();resetPositions();$("roomLabel").textContent="SALA "+room;$("p1tag").textContent=isHost?me:other;$("p2tag").textContent=isHost?other:me});
 conn.on("data",d=>receive(d));
 conn.on("close",()=>{toast("RIVAL DESCONECTADO");});
}
function receive(d){
 if(d.type==="hello"){other=d.name||"Rival";$("p2tag").textContent=other;if(isHost)conn.send({type:"state",p1,p2,ball,score,timeLeft})}
 if(d.type==="input"&&isHost){applyInput(p2,d.input,0.8);broadcast()}
 if(d.type==="state"&&!isHost){p1=d.p1;p2=d.p2;ball=d.ball;score=d.score;timeLeft=d.timeLeft;updateScore()}
 if(d.type==="goal"){score=d.score;updateScore();flash("¡GOL!");resetAfterGoal(d.team)}
}
function sendInput(){if(conn?.open)conn.send({type:"input",input:{up:keys.up||touch.up,down:keys.down||touch.down,left:keys.left||touch.left,right:keys.right||touch.right,kick:keys.kick||touch.kick}})}
function applyInput(p,i,dt){let ax=(i.right?1:0)-(i.left?1:0),ay=(i.down?1:0)-(i.up?1:0);let len=Math.hypot(ax,ay)||1;p.vx+=ax*900*dt;p.vy+=ay*900*dt;p.vx*=.82;p.vy*=.82;p.x+=p.vx*dt;p.y+=p.vy*dt;p.x=Math.max(field.x+playerR,Math.min(field.x+field.w-playerR,p.x));p.y=Math.max(field.y+playerR,Math.min(field.y+field.h-playerR,p.y));if(i.kick&&Math.hypot(ball.x-p.x,ball.y-p.y)<70){let dx=ball.x-p.x,dy=ball.y-p.y,l=Math.hypot(dx,dy)||1;ball.vx+=dx/l*950;ball.vy+=dy/l*950}}
function physics(dt){
 applyInput(p1,{up:keys.up||touch.up,down:keys.down||touch.down,left:keys.left||touch.left,right:keys.right||touch.right,kick:keys.kick||touch.kick},dt);
 ball.x+=ball.vx*dt;ball.y+=ball.vy*dt;ball.vx*=.992;ball.vy*=.992;
 for(const p of [p1,p2]){let dx=ball.x-p.x,dy=ball.y-p.y,d=Math.hypot(dx,dy);if(d<playerR+13){let l=d||1;ball.x=p.x+dx/l*(playerR+14);ball.y=p.y+dy/l*(playerR+14);ball.vx+=dx/l*90+ p.vx*.18;ball.vy+=dy/l*90+p.vy*.18}}
 if(ball.y<field.y+13||ball.y>field.y+field.h-13){ball.vy*=-.9;ball.y=Math.max(field.y+13,Math.min(field.y+field.h-13,ball.y))}
 let goalTop=H/2-goalH/2,goalBot=H/2+goalH/2;
 if(ball.x<field.x-8){if(ball.y>goalTop&&ball.y<goalBot)goal(1);else{ball.x=field.x+10;ball.vx=Math.abs(ball.vx)*.9}}
 if(ball.x>field.x+field.w+8){if(ball.y>goalTop&&ball.y<goalBot)goal(0);else{ball.x=field.x+field.w-10;ball.vx=-Math.abs(ball.vx)*.9}}
}
function goal(team){score[team]++;updateScore();flash("⚽ ¡GOL!");if(conn?.open)conn.send({type:"goal",team,score});resetAfterGoal(team)}
function resetAfterGoal(){ball={x:W/2,y:H/2,vx:0,vy:0};p1={x:field.x+140,y:H/2,vx:0,vy:0};p2={x:field.x+field.w-140,y:H/2,vx:0,vy:0}}
function broadcast(){if(conn?.open)conn.send({type:"state",p1,p2,ball,score,timeLeft})}
function loop(t){if(!running)return;let dt=Math.min(.033,(t-last)/1000);last=t;if(isHost){physics(dt);timeLeft-=dt;if(timeLeft<=0){timeLeft=0;endMatch();}broadcast()}else{sendInput()}draw();$("timer").textContent=Math.ceil(timeLeft/60).toString().padStart(2,"0")+":"+Math.ceil(timeLeft%60).toString().padStart(2,"0");touch.kick=false;keys.kick=false;requestAnimationFrame(loop)}
function draw(){
 let w=innerWidth,h=innerHeight,s=Math.min((w-20)/1200,(h-20)/650),ox=(w-1200*s)/2,oy=(h-650*s)/2;ctx.save();ctx.translate(ox,oy);ctx.scale(s,s);
 ctx.fillStyle="#07130e";ctx.fillRect(0,0,1200,650);
 ctx.fillStyle="#0b7a45";ctx.fillRect(field.x,field.y,field.w,field.h);
 for(let x=field.x;x<field.x+field.w;x+=80){ctx.fillStyle=((x/80)%2?"#0c8149":"#0b7844");ctx.fillRect(x,field.y,80,field.h)}
 ctx.strokeStyle="#d7fff0";ctx.lineWidth=4;ctx.strokeRect(field.x,field.y,field.w,field.h);ctx.beginPath();ctx.moveTo(600,field.y);ctx.lineTo(600,field.y+field.h);ctx.stroke();ctx.beginPath();ctx.arc(600,325,80,0,Math.PI*2);ctx.stroke();
 ctx.strokeRect(field.x,205,150,240);ctx.strokeRect(field.x+field.w-150,205,150,240);
 ctx.fillStyle="#d8ffff";ctx.fillRect(field.x-18,235,18,180);ctx.fillRect(field.x+field.w,235,18,180);
 player(p1,"#39a7ff");player(p2,"#ff4d70");ballDraw();
 ctx.restore();
}
function player(p,c){ctx.save();ctx.shadowBlur=25;ctx.shadowColor=c;ctx.fillStyle=c;ctx.beginPath();ctx.arc(p.x,p.y,playerR,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(p.x-7,p.y-7,6,0,Math.PI*2);ctx.fill();ctx.fillStyle="#06101f";ctx.font="bold 12px Arial";ctx.textAlign="center";ctx.fillText("★",p.x,p.y+5);ctx.restore()}
function ballDraw(){ctx.save();ctx.shadowBlur=18;ctx.shadowColor="#fff";ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(ball.x,ball.y,13,0,Math.PI*2);ctx.fill();ctx.fillStyle="#15213a";ctx.font="bold 15px Arial";ctx.textAlign="center";ctx.fillText("⬟",ball.x,ball.y+5);ctx.restore()}
function flash(t){let e=$("toast");e.textContent=t;e.style.opacity=1;setTimeout(()=>e.style.opacity=0,800)}
function toast(t){flash(t)}
function endMatch(){running=false;$("game").classList.add("hidden");$("result").classList.remove("hidden");$("finalScore").textContent=score[0]+" : "+score[1];$("winner").textContent=score[0]===score[1]?"EMPATE":score[0]>score[1]?"🔵 VICTORIA":"🔴 DERROTA"}
$("hostBtn").onclick=startHost;$("joinBtn").onclick=startJoin;$("againBtn").onclick=()=>location.reload();
addEventListener("keydown",e=>{let k=e.key.toLowerCase();if(["w","arrowup"].includes(k))keys.up=true;if(["s","arrowdown"].includes(k))keys.down=true;if(["a","arrowleft"].includes(k))keys.left=true;if(["d","arrowright"].includes(k))keys.right=true;if(k===" ")keys.kick=true;if(k==="r"&&isHost)resetAfterGoal()});
addEventListener("keyup",e=>{let k=e.key.toLowerCase();if(["w","arrowup"].includes(k))keys.up=false;if(["s","arrowdown"].includes(k))keys.down=false;if(["a","arrowleft"].includes(k))keys.left=false;if(["d","arrowright"].includes(k))keys.right=false});
document.querySelectorAll("[data-key]").forEach(b=>{let k=b.dataset.key;b.onpointerdown=e=>{e.preventDefault();touch[k]=true};b.onpointerup=b.onpointercancel=()=>touch[k]=false});
$("kickMobile").onpointerdown=e=>{e.preventDefault();touch.kick=true};
