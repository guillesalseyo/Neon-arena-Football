# ⚽ Neon Football Arena

Juego de fútbol arcade 1v1 multijugador online para navegador.

## Publicar en GitHub Pages
1. Crea un repositorio público en GitHub.
2. Sube `index.html`, `style.css` y `game.js`.
3. Ve a **Settings → Pages**.
4. Selecciona la rama `main` y carpeta `/root`.
5. Abre la URL de GitHub Pages.

## Cómo jugar online
- Un jugador pulsa **CREAR SALA** y comparte el código.
- El otro escribe el código y pulsa **UNIRME**.
- PC: WASD/flechas para moverse y Espacio para chutar.
- Móvil: usa los controles táctiles.

La conexión usa PeerJS/WebRTC; GitHub Pages aloja el frontend y no necesita un servidor propio para esta versión.
